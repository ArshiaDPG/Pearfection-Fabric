package net.digitalpear.pearfection.common.features.util;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.world.gen.feature.FeatureConfig;
import net.minecraft.world.gen.feature.PlacedFeature;
import net.minecraft.world.gen.stateprovider.BlockStateProvider;

public class HugePearFeatureConfig implements FeatureConfig {
    public static final Codec<HugePearFeatureConfig> CODEC = RecordCodecBuilder.create((instance) ->
            instance.group(
                    PlacedFeature.REGISTRY_CODEC.fieldOf("feature").forGetter((config) -> config.feature),
                    BlockStateProvider.TYPE_CODEC.fieldOf("base_block_provider").forGetter((config) -> config.baseBlockProvider),
                    BlockStateProvider.TYPE_CODEC.fieldOf("tree_leaves_provider").forGetter((config) -> config.treeLeavesProvider),
                    BlockStateProvider.TYPE_CODEC.fieldOf("flowering_leaves_provider").forGetter((config) -> config.floweringLeavesProvider),
                    BlockStateProvider.TYPE_CODEC.fieldOf("fruit_provider").forGetter((config) -> config.fruitProvider))
                    .apply(instance, HugePearFeatureConfig::new));

    public final BlockStateProvider baseBlockProvider;
    public final BlockStateProvider treeLeavesProvider;
    public final BlockStateProvider floweringLeavesProvider;
    public final BlockStateProvider fruitProvider;
    public final RegistryEntry<PlacedFeature> feature;


    public HugePearFeatureConfig(RegistryEntry<PlacedFeature> feature, BlockStateProvider baseBlockProvider, BlockStateProvider treeLeavesProvider, BlockStateProvider floweringLeavesProvider, BlockStateProvider fruitProvider) {
        this.feature = feature;
        this.baseBlockProvider = baseBlockProvider;
        this.treeLeavesProvider = treeLeavesProvider;
        this.floweringLeavesProvider = floweringLeavesProvider;
        this.fruitProvider = fruitProvider;
    }
}
