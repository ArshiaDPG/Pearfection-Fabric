package net.digitalpear.pearfection.common.features;

import com.mojang.serialization.Codec;
import net.digitalpear.pearfection.common.features.util.HugePearFeatureConfig;
import net.digitalpear.pearfection.init.tags.PearBlockTags;
import net.minecraft.block.BlockState;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.PlacedFeature;
import net.minecraft.world.gen.feature.util.FeatureContext;
import net.minecraft.world.gen.stateprovider.BlockStateProvider;

import java.util.HashMap;
import java.util.Map;

public class HugePearFeature extends Feature<HugePearFeatureConfig> {
    public HugePearFeature(Codec<HugePearFeatureConfig> configCodec) {
        super(configCodec);
    }

    public static boolean isReplaceable(BlockState state) {
        return !state.isIn(PearBlockTags.HUGE_PEAR_CANNOT_REPLACE) && state.getBlock().getHardness() < 1.5;
    }


    @Override
    public boolean generate(FeatureContext<HugePearFeatureConfig> context) {
        BlockPos blockPos = context.getOrigin();
        World world = context.getWorld().toServerWorld();
        Random random = context.getRandom();
        BlockStateProvider baseBlock = context.getConfig().baseBlockProvider;

        int radius = 1;
        int height = random.nextBetween(2, 3);
        Map<Iterable<BlockPos>, BlockState> PLACEMENTS = new HashMap<>();

        if (blockPos.getY() <= world.getBottomY() + 1 && blockPos.getY() + height + 1 < world.getTopY()) {
            return false;
        }

        /*
            Place Stem Feature, if placement fails, don't generate the base
         */
        StructureWorldAccess treeWorld = context.getWorld();
        RegistryEntry<PlacedFeature> tree = context.getConfig().feature;
        BlockStateProvider leaves = context.getConfig().treeLeavesProvider;
        if (!tree.value().generateUnregistered(treeWorld, treeWorld.toServerWorld().getChunkManager().getChunkGenerator(), random, blockPos)){
            return false;
        }
        int size = 20;
        Iterable<BlockPos> SPACES = BlockPos.iterate(blockPos.add(-size/2, 0, -size/2), blockPos.add(size/2, size, size/2));
        SPACES.forEach(pos -> {
            if (world.getBlockState(pos).isOf(leaves.get(random, pos).getBlock()) && random.nextFloat() > 0.6){
                world.setBlockState(pos, context.getConfig().floweringLeavesProvider.get(random, pos));

                if (random.nextFloat() > 0.4 && world.getBlockState(pos.down()).isAir()){
                    world.setBlockState(pos.down(), context.getConfig().fruitProvider.get(random, pos.down()));

                }
            }
        });

        /*
            Collect smaller pear layer
         */
        PLACEMENTS.put(BlockPos.iterate(blockPos.add(-radius, -1, -radius),
                blockPos.add(radius, -height, radius)), baseBlock.get(random, blockPos));

        /*
            Collect bigger pear layer
         */
        PLACEMENTS.put(BlockPos.iterate(blockPos.add(-(radius + 1), -height-1, -(radius + 1)),
                blockPos.add(radius + 1, -(height * 4), radius + 1)), baseBlock.get(random, blockPos));


        /*
            Place all collected maps
         */
        PLACEMENTS.forEach((iterator, state) -> {
            for (BlockPos currentPos : iterator) {
                if (isReplaceable(world.getBlockState(currentPos))) {
                    world.setBlockState(currentPos, state, 2);
                }
            }
        });

        return true;
    }
}
