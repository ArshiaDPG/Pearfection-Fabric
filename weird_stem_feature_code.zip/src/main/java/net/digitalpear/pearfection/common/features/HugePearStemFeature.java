package net.digitalpear.pearfection.common.features;

import com.mojang.serialization.Codec;
import net.digitalpear.pearfection.init.PearBlocks;
import net.digitalpear.pearfection.init.tags.PearBlockTags;
import net.minecraft.block.BlockState;
import net.minecraft.block.PillarBlock;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.util.FeatureContext;

import java.util.HashMap;
import java.util.Map;

public class HugePearStemFeature extends Feature<DefaultFeatureConfig> {
    public HugePearStemFeature(Codec<DefaultFeatureConfig> configCodec) {
        super(configCodec);
    }

    public static boolean isReplaceable(BlockState state) {
        return !state.isIn(PearBlockTags.HUGE_PEAR_CANNOT_REPLACE) && state.getBlock().getHardness() < 1.5;
    }

    @Override
    public boolean generate(FeatureContext<DefaultFeatureConfig> context) {

        BlockPos blockPos = context.getOrigin();
        World world = context.getWorld().toServerWorld();
        Random random = context.getRandom();
        BlockState stem = PearBlocks.CALLERY_STEM.getDefaultState();

        int stemLengthMultiplier = world.random.nextBetween(1, 3);

        Direction turnDirection = getHorizontal(random);
        Map<Iterable<BlockPos>, BlockState> PLACEMENTS = new HashMap<>();


                /*
            Collect stems and place foliage
         */
        PLACEMENTS.put(BlockPos.iterate(blockPos, blockPos.offset(Direction.UP, 2)),
                stem.with(PillarBlock.AXIS, Direction.Axis.Y));

        placeFoliage(world, blockPos.offset(Direction.UP, 2 + stemLengthMultiplier).offset(turnDirection));
        PLACEMENTS.put(BlockPos.iterate(blockPos.offset(Direction.UP, 2).offset(turnDirection), blockPos.offset(Direction.UP, 2 + stemLengthMultiplier).offset(turnDirection)),
                stem.with(PillarBlock.AXIS, Direction.Axis.Y));

        BlockPos newPos = blockPos.offset(Direction.UP, 2 + stemLengthMultiplier).offset(turnDirection);
        placeFoliage(world, newPos);
        PLACEMENTS.put(BlockPos.iterate(newPos, newPos.offset(turnDirection, 1 + stemLengthMultiplier)), stem.with(PillarBlock.AXIS, turnDirection.getAxis()));

        /*
            Place the stems
         */
        PLACEMENTS.forEach((iterator, state) -> {
            for (BlockPos currentPos : iterator) {
                if (isReplaceable(world.getBlockState(currentPos))) {
                    world.setBlockState(currentPos, state, 2);
                }
            }
        });

        return true;
    }
    public static Direction getHorizontal(Random random){
        Direction direction;
        do {
            direction = Direction.random(random);
        } while (direction.getAxis().isVertical());

        return direction;
    }

    public static void placeFoliage(World world, BlockPos blockPos){
        int x = world.random.nextBetween(1, 3);
        int y = world.random.nextInt(1);
        int z = world.random.nextBetween(1, 3);
        float radius = (float)(x + y + z) * 0.333F + 0.5F;
        BlockState leaves = PearBlocks.CALLERY_LEAVES.getDefaultState();

        for (BlockPos currentBlockPos : BlockPos.iterate(blockPos.add(-x, -y, -z), blockPos.add(x, y, z))) {
            if (currentBlockPos.getSquaredDistance(blockPos) <= (double) (radius * radius) && world.getBlockState(currentBlockPos).isAir()) {
                world.setBlockState(currentBlockPos, leaves.with(Properties.WATERLOGGED, world.getBlockState(currentBlockPos).getFluidState().isIn(FluidTags.WATER)), 2);
            }
        }
        x += 1;
        y += 1;
        z += 1;
        for (BlockPos currentBlockPos : BlockPos.iterate(blockPos.add(-x, -y, -z).down(2), blockPos.add(x, y, z).down(2))) {
            if (currentBlockPos.getSquaredDistance(blockPos) <= (double) (radius * radius) && world.getBlockState(currentBlockPos).isAir()) {
                if (world.random.nextFloat() < 0.6f) {
                    /*
                        Place leaves
                     */
                    world.setBlockState(currentBlockPos, leaves
                            .with(Properties.WATERLOGGED, world.getBlockState(currentBlockPos).getFluidState().isIn(FluidTags.WATER)), 2);
                }
            }
        }
    }
}
