package net.digitalpear.pearfection.common.datagens;

import net.digitalpear.pearfection.init.PearBlocks;
import net.digitalpear.pearfection.init.PearItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;

public class PearfectionLanguageGen extends FabricLanguageProvider {
    public PearfectionLanguageGen(FabricDataOutput dataOutput) {
        super(dataOutput);
    }

    @Override
    public void generateTranslations(TranslationBuilder translationBuilder) {
        translationBuilder.add(PearBlocks.LAMPEAR, "Lampear");
        translationBuilder.add(PearBlocks.COPPER_LAMPEAR, "Copper Lampear");

        translationBuilder.add(PearBlocks.PEAR_BLOCK, "Pear Block");
        translationBuilder.add(PearBlocks.CALLERY_BUTTON, "Callery Button");
        translationBuilder.add(PearBlocks.CALLERY_DOOR, "Callery Door");
        translationBuilder.add(PearBlocks.CALLERY_TRAPDOOR, "Callery Trapdoor");

        translationBuilder.add(PearBlocks.CALLERY_PLANKS, "Callery Planks");
        translationBuilder.add(PearBlocks.CALLERY_SLAB, "Callery Slab");
        translationBuilder.add(PearBlocks.CALLERY_STAIRS, "Callery Stairs");

        translationBuilder.add(PearBlocks.CALLERY_FENCE, "Callery Fence");
        translationBuilder.add(PearBlocks.CALLERY_FENCE_GATE, "Callery Fence Gate");

        translationBuilder.add(PearBlocks.CALLERY_HANGING_SIGN, "Callery Hanging Sign");
        translationBuilder.add(PearBlocks.CALLERY_SIGN, "Callery Sign");

        translationBuilder.add(PearBlocks.CALLERY_LEAVES, "Callery Leaves");
        translationBuilder.add(PearBlocks.CALLERY_STEM, "Callery Stem");
        translationBuilder.add(PearBlocks.STRIPPED_CALLERY_STEM, "Stripped Callery Stem");
        translationBuilder.add(PearBlocks.CALLERY_WOOD, "Callery Wood");
        translationBuilder.add(PearBlocks.STRIPPED_CALLERY_WOOD, "Stripped Callery Wood");
        translationBuilder.add(PearBlocks.CALLERY_PRESSURE_PLATE, "Callery Pressure Plate");
        translationBuilder.add("subtitles.block.pear.step", "Footsteps");


        translationBuilder.add(PearItems.PEAR_TART, "Pear Tart");
        translationBuilder.add(PearItems.CALLERY_BOAT, "Callery Boat");
        translationBuilder.add(PearItems.CALLERY_CHEST_BOAT, "Callery Boat with Chest");

    }
}
