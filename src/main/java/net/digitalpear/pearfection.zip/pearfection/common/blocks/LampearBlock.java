package net.digitalpear.pearfection.common.blocks;

import net.digitalpear.pearfection.init.PearConfiguredFeatures;
import net.digitalpear.pearfection.init.tags.PearBlockTags;
import net.minecraft.block.*;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.minecraft.world.gen.feature.ConfiguredFeature;

public class LampearBlock extends LanternBlock implements Fertilizable {
    public static final int MAX_AGE = 7;
    public static final IntProperty AGE = Properties.AGE_7;
    public RegistryKey<ConfiguredFeature<?, ?>> tree;
    protected static final VoxelShape STANDING_SHAPE = VoxelShapes.union(
            Block.createCuboidShape(5.0D, 0.0D, 5.0D, 11.0D, 6.0D, 11.0D),
            Block.createCuboidShape(6.0D, 6.0D, 6.0D, 10.0D, 9.0D, 10.0D));
    protected static final VoxelShape HANGING_SHAPE = VoxelShapes.union(
            Block.createCuboidShape(5.0D, 1.0D, 5.0D, 11.0D, 7.0D, 11.0D),
            Block.createCuboidShape(6.0D, 7.0D, 6.0D, 10.0D, 10.0D, 10.0D));

    public LampearBlock(RegistryKey<ConfiguredFeature<?, ?>> tree, Settings settings) {
        super(settings);
        this.setDefaultState(this.stateManager.getDefaultState().with(HANGING, false).with(WATERLOGGED, false).with(AGE, 0));
        this.tree = tree;
    }
    public LampearBlock(Settings settings) {
        super(settings);
        this.setDefaultState(this.stateManager.getDefaultState().with(HANGING, false).with(WATERLOGGED, false).with(AGE, 0));
        this.tree = PearConfiguredFeatures.HUGE_PEAR;
    }

    @Override
    public boolean isFertilizable(WorldView world, BlockPos pos, BlockState state, boolean isClient) {
        return !state.get(HANGING);
    }

    @Override
    public boolean canGrow(World world, Random random, BlockPos pos, BlockState state) {
        return true;
    }


    @Override
    public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return state.get(HANGING) ? HANGING_SHAPE : STANDING_SHAPE;
    }

    @Override
    public boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
        Direction direction = attachedDirection(state).getOpposite();
        if (world.getBlockState(pos.offset(direction)).isIn(BlockTags.LEAVES)){
            return true;
        }
        else{
            return super.canPlaceAt(state, world, pos);
        }
    }
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(AGE);
        super.appendProperties(builder);
    }

    protected int getGrowthAmount(World world) {
        return world.random.nextBetween(1, 2);
    }

    public void applyGrowth(World world, BlockPos pos, BlockState state) {
        int i = state.get(AGE) + this.getGrowthAmount(world);
        if (i > MAX_AGE) {
            i = MAX_AGE;
        }
        world.setBlockState(pos, getStateWithProperties(state).with(AGE, i), 2);
    }

    @Override
    public void grow(ServerWorld world, Random random, BlockPos pos, BlockState state) {
        if (state.get(AGE) < MAX_AGE){
            applyGrowth(world, pos, state);
        }
        else if (!state.get(HANGING) && world.getBlockState(pos.down()).isIn(PearBlockTags.PEAR_GROWABLE_ON)){
            world.getRegistryManager().getOptional(RegistryKeys.CONFIGURED_FEATURE).flatMap((registry) ->
                    registry.getEntry(tree)).ifPresent((reference) ->
                    reference.value().generate(world, world.getChunkManager().getChunkGenerator(),
                            random, pos.down()));
        }
    }
}
