package net.digitalpear.pearfection.common.datagens;

import net.digitalpear.pearfection.Pearfection;
import net.digitalpear.pearfection.common.datagens.misc.PearBlockLootTables;
import net.digitalpear.pearfection.init.PearBlocks;
import net.digitalpear.pearfection.init.PearItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.SimpleFabricLootTableProvider;
import net.minecraft.block.Block;
import net.minecraft.data.server.loottable.BlockLootTableGenerator;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.condition.TableBonusLootCondition;
import net.minecraft.loot.context.LootContextTypes;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.function.SetCountLootFunction;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;
import net.minecraft.loot.provider.number.UniformLootNumberProvider;
import net.minecraft.registry.Registries;
import net.minecraft.resource.featuretoggle.FeatureFlags;
import net.minecraft.util.Identifier;

import java.util.Set;
import java.util.function.BiConsumer;

public class PearfectionBlockLootTableGen extends SimpleFabricLootTableProvider {
    public PearfectionBlockLootTableGen(FabricDataOutput output) {
        super(output, LootContextTypes.BLOCK);
    }

    public static final BlockLootTableGenerator BLTG = new PearBlockLootTables(Set.of(Items.NETHER_STAR), FeatureFlags.VANILLA_FEATURES);

    @Override
    public void accept(BiConsumer<Identifier, LootTable.Builder> biConsumer) {
        simpleDrop(biConsumer, PearBlocks.LAMPEAR);
        simpleDrop(biConsumer, PearBlocks.COPPER_LAMPEAR);

        simpleDrop(biConsumer, PearBlocks.CALLERY_STEM);
        simpleDrop(biConsumer, PearBlocks.STRIPPED_CALLERY_STEM);
        simpleDrop(biConsumer, PearBlocks.CALLERY_WOOD);
        simpleDrop(biConsumer, PearBlocks.STRIPPED_CALLERY_WOOD);

        simpleDrop(biConsumer, PearBlocks.CALLERY_PLANKS);
        simpleDrop(biConsumer, PearBlocks.CALLERY_STAIRS);
        makeSlab(biConsumer, BLTG, PearBlocks.CALLERY_SLAB);

        simpleDrop(biConsumer, PearBlocks.CALLERY_PRESSURE_PLATE);
        simpleDrop(biConsumer, PearBlocks.CALLERY_BUTTON);

        simpleDrop(biConsumer, PearBlocks.CALLERY_FENCE);
        simpleDrop(biConsumer, PearBlocks.CALLERY_FENCE_GATE);

        makeDoor(biConsumer, BLTG, PearBlocks.CALLERY_DOOR);
        simpleDrop(biConsumer, PearBlocks.CALLERY_TRAPDOOR);

        makeLeaves(biConsumer, BLTG, PearBlocks.CALLERY_LEAVES);
        simpleDrop(biConsumer, PearBlocks.PEAR_BLOCK);

        simpleDrop(biConsumer, PearBlocks.CALLERY_SIGN, PearItems.CALLERY_SIGN);
        simpleDrop(biConsumer, PearBlocks.CALLERY_HANGING_SIGN, PearItems.CALLERY_HANGING_SIGN);
    }

    public static void makeSlab(BiConsumer<Identifier, LootTable.Builder> biConsumer, BlockLootTableGenerator blockLootTableGenerator, Block slab){
        biConsumer.accept(getPearfectionNamespacedBlock(slab), blockLootTableGenerator.slabDrops(slab));
    }
    public static void makeLeaves(BiConsumer<Identifier, LootTable.Builder> biConsumer, BlockLootTableGenerator blockLootTableGenerator, Block leaves) {
        biConsumer.accept(getPearfectionNamespacedBlock(leaves), BlockLootTableGenerator.dropsWithSilkTouchOrShears(leaves, ((net.minecraft.loot.entry.LeafEntry.Builder)blockLootTableGenerator.applyExplosionDecay(leaves,
                ItemEntry.builder(Items.STICK).apply(SetCountLootFunction.builder(UniformLootNumberProvider.create(1.0F, 2.0F))))).conditionally(TableBonusLootCondition.builder(Enchantments.FORTUNE, 0.02F, 0.022222223F, 0.025F, 0.033333335F, 0.1F))));
    }
    public static void makeDoor(BiConsumer<Identifier, LootTable.Builder> biConsumer, BlockLootTableGenerator blockLootTableGenerator, Block door){
        biConsumer.accept(getPearfectionNamespacedBlock(door), blockLootTableGenerator.doorDrops(door));
    }


    public static Identifier getPearfectionNamespacedBlock(Block name) {
        return new Identifier(Pearfection.MOD_ID, "blocks/" + Registries.BLOCK.getId(name).getPath());
    }

    public static void simpleDrop(BiConsumer<Identifier, LootTable.Builder> biConsumer, Block block){
        biConsumer.accept(getPearfectionNamespacedBlock(block), drops(block.asItem()));
    }
    public static void simpleDrop(BiConsumer<Identifier, LootTable.Builder> biConsumer, Block block, Item drop){
        biConsumer.accept(getPearfectionNamespacedBlock(block), drops(drop));
    }


    public static net.minecraft.loot.LootTable.Builder drops(Item drop) {
        return LootTable.builder().pool(LootPool.builder().rolls(ConstantLootNumberProvider.create(1.0F))
                .with(ItemEntry.builder(drop)));
    }
}
