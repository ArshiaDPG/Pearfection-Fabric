package net.digitalpear.pearfection.init.data;

import net.digitalpear.pearfection.init.PearBlocks;
import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.fabricmc.fabric.api.registry.CompostingChanceRegistry;
import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.fabricmc.fabric.api.registry.StrippableBlockRegistry;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.LootTables;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.function.SetCountLootFunction;
import net.minecraft.loot.provider.number.UniformLootNumberProvider;
import net.minecraft.resource.featuretoggle.FeatureSet;
import net.minecraft.util.Rarity;
import net.minecraft.village.TradeOffer;

public class PearData {
    public static void registerFlammableBlock(){
        FlammableBlockRegistry instance = FlammableBlockRegistry.getDefaultInstance();
        instance.add(PearBlocks.LAMPEAR, 30, 40);
        instance.add(PearBlocks.PEAR_BLOCK, 7, 7);
        instance.add(PearBlocks.CALLERY_STEM, 5, 5);
        instance.add(PearBlocks.STRIPPED_CALLERY_STEM, 5, 5);
        instance.add(PearBlocks.CALLERY_WOOD, 5, 5);
        instance.add(PearBlocks.STRIPPED_CALLERY_WOOD, 5, 5);
        instance.add(PearBlocks.CALLERY_PLANKS, 5, 15);
        instance.add(PearBlocks.CALLERY_STAIRS, 5, 20);
        instance.add(PearBlocks.CALLERY_SLAB, 5, 20);
        instance.add(PearBlocks.CALLERY_FENCE, 5, 20);
        instance.add(PearBlocks.CALLERY_FENCE_GATE, 5, 20);
        instance.add(PearBlocks.CALLERY_LEAVES, 30, 60);
    }

    public static void registerStrippables(){
        StrippableBlockRegistry.register(PearBlocks.CALLERY_STEM, PearBlocks.STRIPPED_CALLERY_STEM);
        StrippableBlockRegistry.register(PearBlocks.CALLERY_WOOD, PearBlocks.STRIPPED_CALLERY_WOOD);
    }

    public static void registerFuels(){
        FuelRegistry registry = FuelRegistry.INSTANCE;
        registry.add(PearBlocks.PEAR_BLOCK, 10 * 200);
    }


    public static void registerTrades(){
        TradeOfferHelper.registerWanderingTraderOffers(1, factories -> {
            factories.add((entity, random) -> new TradeOffer(
                    new ItemStack(Items.EMERALD, 5),
                    new ItemStack(PearBlocks.LAMPEAR),
                    3,0,0.02f));
        });
    }

    public static void registerLootTableModifications(){
        LootTableEvents.MODIFY.register((resourceManager, lootManager, id, tableBuilder, source) -> {
            if (LootTables.ABANDONED_MINESHAFT_CHEST.equals(id) && source.isBuiltin()) {
                LootPool.Builder pool = LootPool.builder().with(ItemEntry.builder(PearBlocks.LAMPEAR).weight(1).quality(Rarity.RARE.ordinal() + 1))
                        .apply(SetCountLootFunction.builder(UniformLootNumberProvider.create(0.0F, 2.0F)));
                tableBuilder.pool(pool);
            }
            if (LootTables.PILLAGER_OUTPOST_CHEST.equals(id) && source.isBuiltin()) {
                LootPool.Builder pool = LootPool.builder().with(ItemEntry.builder(PearBlocks.LAMPEAR).weight(2).quality(Rarity.RARE.ordinal() + 1))
                        .apply(SetCountLootFunction.builder(UniformLootNumberProvider.create(1.0F, 4.0F)));
                tableBuilder.pool(pool);
            }
            if (LootTables.WOODLAND_MANSION_CHEST.equals(id) && source.isBuiltin()) {
                LootPool.Builder pool = LootPool.builder().with(ItemEntry.builder(PearBlocks.LAMPEAR).weight(2).quality(Rarity.RARE.ordinal() + 1))
                        .apply(SetCountLootFunction.builder(UniformLootNumberProvider.create(2.0F, 6.0F)));
                tableBuilder.pool(pool);
            }
        });
    }



    public static void init(){
        registerStrippables();
        registerFlammableBlock();
        registerFuels();
        registerTrades();
        registerLootTableModifications();



        CompostingChanceRegistry.INSTANCE.add(PearBlocks.PEAR_BLOCK, 0.85F);
        CompostingChanceRegistry.INSTANCE.add(PearBlocks.LAMPEAR, 0.65F);
        CompostingChanceRegistry.INSTANCE.add(PearBlocks.COPPER_LAMPEAR, 0.65F);
    }
}
