package net.digitalpear.pearfection.mixin;

import net.digitalpear.pearfection.init.PearBlocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.passive.SnifferEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(SnifferEntity.class)
public abstract class SnifferEntityMixin extends AnimalEntity {
    private static final List<Item> SEEDS = List.of(Items.TORCHFLOWER_SEEDS, PearBlocks.LAMPEAR.asItem());

    @Shadow @Final private static TrackedData<Integer> FINISH_DIG_TIME;

    @Shadow protected abstract BlockPos getDigPos();

    protected SnifferEntityMixin(EntityType<? extends AnimalEntity> entityType, World world) {
        super(entityType, world);
    }

    @Inject(method = "dropSeeds", at = @At("HEAD"), cancellable = true)
    private void injected(CallbackInfo ci) {
            Dig:if (!this.world.isClient() && this.dataTracker.get(FINISH_DIG_TIME) == this.age) {
                ItemStack itemStack = new ItemStack(SEEDS.get(world.getRandom().nextInt(SEEDS.size())));
                BlockPos blockPos = this.getDigPos();
                ItemEntity itemEntity = new ItemEntity(this.world, blockPos.getX(), blockPos.getY(), blockPos.getZ(), itemStack);
                itemEntity.setToDefaultPickupDelay();
                this.world.spawnEntity(itemEntity);
                this.playSound(SoundEvents.ENTITY_SNIFFER_DROP_SEED, 1.0F, 1.0F);
                break Dig;
            }
    }


    @Nullable
    @Override
    public PassiveEntity createChild(ServerWorld world, PassiveEntity entity) {
        return EntityType.SNIFFER.create(world);
    }
}
